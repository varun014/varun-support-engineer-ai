import pandas as pd, re, sys
d=pd.read_csv(sys.argv[1],dtype=str)
num=lambda c: pd.to_numeric(d[c],errors='coerce')
m=num('Marks Obtained')
roman={'1':'I','9':'IX'}
def clean(s):
    s=str(s).strip(); x=s.split()[-1].upper(); x=roman.get(x,x); return 'Sem '+x
d['sem_clean']=d.Semester.map(clean)
print('rows',len(d),'admno',d.Admno.nunique(),'codes',d.Code.nunique(),'marks',m.notna().sum(),
 'notdone',(d['Marks Entry Status']=='Not Done').sum(),'snf',(d['Exam Name']=='Scheme Not Found').sum(),
 'pubnomarks',((d['Result Publish']=='Published')&m.isna()).sum())
print(d[d['Marks Entry Status']=='Not Done'].groupby(['Code','Course']).size().sort_values(ascending=False).head(7))
print(d[d['Exam Name']=='Scheme Not Found'].groupby(['Department','sem_clean']).size().sort_values(ascending=False).head(7))
print('snf by sem', d[d['Exam Name']=='Scheme Not Found'].sem_clean.value_counts())
# anomalies
neg=d[m<0]; print('neg',len(neg),neg['Sr.'].tolist(), neg[['Scaled Marks','Scaled MaxMarks','Max Marks']].drop_duplicates().values)
sm=num('Scaled Marks'); print('scaled mismatch rows',d[(sm!=m)&m.notna()]['Sr.'].tolist())
print('maxmarks blank',d['Max Marks'].isna().sum(),' blank where marks present',(m.notna()&d['Max Marks'].isna()).sum())
ex=d.drop(columns='Sr.').duplicated(keep=False); print('exact dup rows',ex.sum(),d[ex]['Sr.'].tolist())
k=d[d['Exam Name']!='Scheme Not Found']; kd=k.duplicated(['Admno','Code','Exam Name'],keep=False)
print('same key non-SNF rows',kd.sum(),'groups',k[kd].groupby(['Admno','Code']).ngroups)
kk=k[kd]; g=kk.groupby(['Admno','Code']).sem_clean.nunique(); print('of which diff clean sem',(g>1).sum(),'same clean sem',(g==1).sum())
s=d[d['Exam Name']=='Scheme Not Found']; print('SNF dup rows',s.duplicated(['Admno','Code'],keep=False).sum())
both=set(zip(s.Admno,s.Code))&set(zip(k.Admno,k.Code)); print('admno+code both ETE & SNF',len(both))
print('pub+SNF',((d['Exam Name']=='Scheme Not Found')&(d['Result Publish']=='Published')).sum())
print('pub+notreg',((d['Result Publish']=='Published')&(d['Register Status']=='Not Registered')).sum())
print('processed+not done',((d['Result Process']=='Processed')&(d['Marks Entry Status']=='Not Done')).sum())
print('pub+notdone',((d['Result Publish']=='Published')&(d['Marks Entry Status']=='Not Done')).sum())
print('pub+unfreeze',((d['Result Publish']=='Published')&(d['Freeze/Unfreeze Status']=='Unfreeze')).sum())
print('done+unfreeze',((d['Marks Entry Status']=='Done')&(d['Freeze/Unfreeze Status']=='Unfreeze')).sum())
print('sem variants',d.Semester.nunique(), 'rows non-std',(d.Semester!=d.sem_clean).sum())
print('double space names',d.Student.str.contains('  ').sum())
print('exam session blank',d['Exam Session'].isna().sum(), 'batch blank',d.Batch.isna().sum(),'division blank',d.Division.isna().sum(),'empid blank',d['Alloted EmpId'].isna().sum())
print('type',d.Type.value_counts().to_dict())
print('class year mismatches?', d.Class.str.extract(r'(20\d\d)')[0].value_counts().head())
print(d[d.Department.str.contains('Forensic')].Department.value_counts())
print('example pub no marks',d[(d['Result Publish']=='Published')&m.isna()].iloc[0][['Sr.','Admno','Code','Exam Name']].tolist())
print('example pub+SNF',d[(d['Exam Name']=='Scheme Not Found')&(d['Result Publish']=='Published')].iloc[0][['Sr.','Admno','Code','Department','Semester']].tolist())
print('example both',list(both)[:2]); 
print('dup example sr', kk.sort_values(['Admno','Code'])[['Sr.','Admno','Code','Semester']].head(2).values)
print('sem examples', d.drop_duplicates('Semester')[['Semester','Sr.']].values.tolist())
