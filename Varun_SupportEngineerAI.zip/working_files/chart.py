import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
labels=['Marks present','Marks not entered\n(Not Done)','Exam scheme missing\n(Scheme Not Found)']
vals=[104,1638,1025]; cols=['#0ca30c','#ec835a','#d03b3b']; tot=2767
fig,ax=plt.subplots(figsize=(9,3.6),dpi=200); fig.patch.set_facecolor('#fcfcfb'); ax.set_facecolor('#fcfcfb')
y=[2,1,0]
for yi,v,c in zip(y,vals,cols):
    ax.add_patch(FancyBboxPatch((0,yi-0.28),v,0.56,boxstyle="round,pad=0,rounding_size=4",mutation_aspect=0.004,fc=c,ec='none'))
    ax.text(v+25,yi,f'{v:,} rows  ({v/tot:.0%})',va='center',fontsize=11,color='#0b0b0b')
ax.set_yticks(y); ax.set_yticklabels(labels,fontsize=10.5,color='#52514e')
ax.set_xlim(0,2150); ax.set_ylim(-0.6,2.6)
for s in ['top','right','left']: ax.spines[s].set_visible(False)
ax.spines['bottom'].set_color('#d6d5d0'); ax.tick_params(axis='x',colors='#52514e',labelsize=9); ax.tick_params(axis='y',length=0)
ax.xaxis.grid(True,color='#ecebe7',lw=0.8); ax.set_axisbelow(True)
ax.set_title('Exam-Wise Report, Special Exam Sep 2025-26: 2,767 rows',loc='left',fontsize=13,color='#0b0b0b',pad=12)
fig.text(0.012,0.02,'96% of rows have no marks to show: 59% were never entered, 37% have no exam scheme set up. The report itself is working.',fontsize=9.5,color='#52514e')
plt.tight_layout(rect=(0,0.06,1,1)); plt.savefig('out/task2_chart.png',facecolor='#fcfcfb')
