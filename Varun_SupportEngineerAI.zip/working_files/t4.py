import pandas as pd, sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
d=pd.read_csv('data/exp.csv',dtype=str); r=pd.read_csv('data/rev.csv',dtype=str,keep_default_na=False)
tmpl=pd.read_csv('/mnt/user-data/uploads/ba8fa1d5-temp_table_upload_template.csv').columns.tolist()
d['nm']=d.Student.str.split().str.join(' ')
r['code']=r['Paper Code'].str.strip().str.upper()
exp_pairs=d.groupby(['Admno','Code'])
admset=set(d.Admno)
info={}
for _,x in r.iterrows():
    k=(x['Enrollment No'],x['code'])
    if k in exp_pairs.groups:
        g=exp_pairs.get_group(k)
        info[x['S.No']]=dict(type='/'.join(sorted(set(g.Type))),scheme='/'.join(sorted(set(g['Exam Name']))),name=g.nm.iloc[0],
                            status='/'.join(sorted(set(g['Marks Entry Status'].dropna()))),pub='/'.join(sorted(set(g['Result Publish']))))
    else: info[x['S.No']]=dict(type='',scheme='NOT IN EXPORT',name='',status='',pub='')
dupkeys=r.groupby(['Enrollment No','code']).filter(lambda g:len(g)>1)['S.No'].tolist()

E=[]  # S.No, issue, category, severity, action, owner, in_upload
def ex(s,issue,cat,sev,action,owner,inc): E.append([int(s),issue,cat,sev,action,owner,inc])
hold=set()
for _,x in r.iterrows():
    s=x['S.No']; rv=x['Revised Marks'].strip(); old=x['Old Marks']; mx=float(x['Max Marks'])
    try: rvn=float(rv)
    except: rvn=None
    if x['Enrollment No'] not in admset or len(x['Enrollment No'])!=13:
        ex(s,f"Enrollment No '{x['Enrollment No']}' is {len(x['Enrollment No'])} characters (valid = 13) and is not in the ERP export. Roll No {x['Roll No']} starts with 21 but enrollment starts with 22.",'Invalid student ID','High','Send back: client to confirm the correct Enrollment No.','COE office','No'); hold.add(s)
    if rv=='':
        ex(s,'Revised Marks is blank.','Missing marks','High','Send back: client to supply the revised mark (or confirm "no change").','COE office','No'); hold.add(s)
    elif rv.upper()=='AB':
        ex(s,f"Revised Marks = 'AB' (absent) with remark '{x['Remarks']}'. Student wrote the exam (old marks {old}); a re-check is a re-evaluation of the same script, so 'absent' is not a valid outcome.",'Invalid marks value','High','Hold: do not upload. COE to confirm in writing whether marks stay at the old value or another decision applies.','COE / Controller of Examination','No'); hold.add(s)
    elif rvn is not None and rvn>mx:
        ex(s,f'Revised Marks {rv} exceeds Max Marks {x["Max Marks"]}. Likely a typo (e.g. 52 or 62) but we cannot guess.','Impossible marks','High','Send back: client to correct the mark. Never cap or guess.','COE office','No'); hold.add(s)
    elif rvn is not None and rvn!=int(rvn):
        ex(s,f'Revised Marks {rv} is a decimal (half mark). Old marks are whole numbers.','Needs confirmation','Medium','Hold: confirm half marks are allowed in this scheme and how the ERP rounds them. Do not round ourselves.','COE office','No'); hold.add(s)
    elif rvn is not None and rvn<float(old):
        ex(s,f'Revised Marks {rv} is LOWER than Old Marks {old} (remark: "{x["Remarks"]}").','Marks decreased','High','Hold: upload only after written COE approval that the university policy allows a decrease on re-check.','COE / Controller of Examination','No'); hold.add(s)
    elif rvn is not None and rvn==float(old):
        ex(s,f'Revised Marks equal Old Marks ({old}): no change after re-check.','No change (info)','Low','Upload as-is (records the re-check outcome). Mention in reply so client can confirm.','Support (inform client)','Yes')
    if s in dupkeys:
        other=[t for t in r[(r['Enrollment No']==x['Enrollment No'])&(r.code==x['code'])]['S.No'] if t!=s]
        ex(s,f"Duplicate: same student + paper as S.No {', '.join(other)}, but revised marks differ ({', '.join(r[(r['Enrollment No']==x['Enrollment No'])&(r.code==x['code'])]['Revised Marks'])}).",'Duplicate / conflicting','High','Send back: upload neither row until client confirms which mark is correct.','COE office','No'); hold.add(s)
    if x['Paper Code']!=x['code']:
        ex(s,f"Paper Code '{x['Paper Code']}' has lowercase letters / trailing space.",'Format','Low',f"Fixed by support: changed to '{x['code']}' (format only, marks unchanged).",'Support','Yes')
    if info[s]['name'] and info[s]['name'].lower()!=x['Student Name'].lower():
        ex(s,f"Student Name '{x['Student Name']}' is a placeholder. ERP name for this Enrollment No + Roll No + Programme is '{info[s]['name']}'.",'Wrong name','Medium',"Fixed by support: used ERP name in upload (ID, roll no and programme all match; marks unchanged). Ask client to confirm.",'Support (client to confirm)','Yes')
    sem=x['Semester']
    if sem!='Sem '+sem.split()[-1].upper():
        ex(s,f"Semester written as '{sem}'.",'Format','Low','No action: semester is not an upload column. Noted for client.','Support','Yes' if s not in hold else 'No')
# global/row note re old marks and scheme
for _,x in r.iterrows():
    s=x['S.No']
    if 'Scheme Not Found' in info[s]['scheme']:
        pass
# fix 'Yes' for format rows that are held
E=[[*e[:6],('No' if str(e[0]) in hold else e[6])] for e in E]
E.sort(key=lambda e:({'High':0,'Medium':1,'Low':2}[e[3]],e[0]))

# upload
up=[]
for _,x in r.iterrows():
    s=x['S.No']
    if s in hold: continue
    name=info[s]['name'] if info[s]['name'].lower()!=x['Student Name'].lower() else x['Student Name']
    rv=x['Revised Marks'].strip()
    row=dict(sessId='',admno=x['Enrollment No'],rollno=x['Roll No'],studentName=name,subCode=x['code'],subName=x['Paper Name'].strip(),
      ssType=info[s]['type'],examName='ETE-1',sequenceNo=1,questionNo=1,marks=rv,maxMarks=x['Max Marks'],qType='',bloomsLevel='',coMapping='',
      coDifficulty='',qLabel='',acadYear='2025-2026',examSession='Revaluation Re Check Form Winter 2025-2026',totalMarks=rv,totalMaxMarks=x['Max Marks'])
    up.append(row)
U=pd.DataFrame(up)[tmpl]; U.to_csv('out/GU-16432_upload_ready.csv',index=False)
print(len(U),'upload rows; held',sorted(hold,key=int))

# workbook
wb=Workbook(); F='Arial'
hf=Font(name=F,bold=True,color='FFFFFF'); hfill=PatternFill('solid',fgColor='1F3864'); thin=Side(style='thin',color='BFBFBF')
fills={'High':'F8D7DA','Medium':'FFF3CD','Low':'E2EFDA'}
def sheet(ws,headers,rows,widths,sevcol=None):
    ws.append(headers)
    for c in ws[1]: c.font=hf; c.fill=hfill; c.alignment=Alignment(wrap_text=True,vertical='center')
    for rw in rows:
        ws.append(rw)
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.font=Font(name=F,size=10); c.alignment=Alignment(wrap_text=True,vertical='top'); c.border=Border(top=thin,bottom=thin,left=thin,right=thin)
        if sevcol is not None:
            row[sevcol].fill=PatternFill('solid',fgColor=fills[row[sevcol].value])
    for i,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(i)].width=w
    ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
# Summary
ws=wb.active; ws.title='Summary'
ws['A1']='GU-16432 - Re-evaluation marks (Winter 2025-26): validation summary'; ws['A1'].font=Font(name=F,bold=True,size=13)
ws['A2']='Source: revaluation_marks_winter_2025-26 (received as CSV, brief names it .xlsx). Checked against exam_wise_report_export.csv and common sense.'; ws['A2'].font=Font(name=F,size=9,italic=True)
lab=[('Rows received',"=COUNTA('Row Check'!A:A)-1"),
     ('Rows ready to upload',"=COUNTIF('Row Check'!N:N,\"Yes\")"),
     ('Rows held / sent back',"=COUNTIF('Row Check'!N:N,\"No\")"),
     ('Exception lines (High)',"=COUNTIF(Exceptions!D:D,\"High\")"),
     ('Exception lines (Medium)',"=COUNTIF(Exceptions!D:D,\"Medium\")"),
     ('Exception lines (Low)',"=COUNTIF(Exceptions!D:D,\"Low\")"),
     ('Rows whose course shows BOTH ETE-1 and "Scheme Not Found" in the report',"=COUNTIF('Row Check'!K:K,\"*Scheme Not Found*\")")]
for i,(a,b) in enumerate(lab,4):
    ws.cell(i,1,a).font=Font(name=F,size=10); c=ws.cell(i,2,b); c.font=Font(name=F,size=10,bold=True)
notes=['Key notes:',
 '1. No mark has been changed by support. Only format fixes (paper code case/space, placeholder name) were made, each logged in Exceptions.',
 '2. Old Marks cannot be verified in the ERP: the report export has no marks for any of these students/courses (all Not Done or Scheme Not Found), and it is a different session (Special Exam Sep 2025-26).',
 '3. Most rows map to courses that show a "Scheme Not Found" record in the report. Confirm the ETE-1 scheme exists for the Winter 2025-26 Revaluation session BEFORE pushing from the temp table, or those rows will fail.',
 '4. qType could not be filled (no source column; value comes from the exam scheme). totalMarks/totalMaxMarks were set = marks/maxMarks on the assumption of a single-question (questionNo 1) entry.']
for i,t in enumerate(notes,13):
    c=ws.cell(i,1,t); c.font=Font(name=F,size=10,bold=(i==13)); 
ws.column_dimensions['A'].width=75; ws.column_dimensions['B'].width=12
# Exceptions
sheet(wb.create_sheet('Exceptions'),['S.No','What is wrong','Category','Severity','What we will do','Who decides / owner','In upload file?'],E,[7,60,20,10,55,24,11],sevcol=3)
# Row check
rows=[]
for _,x in r.iterrows():
    s=x['S.No']; i=info[s]
    rows.append([int(s),x['Enrollment No'],x['Roll No'],x['Student Name'],x['Paper Code'],x['Paper Name'],x['Old Marks'],x['Revised Marks'],
                 'Yes' if x['Enrollment No'] in admset else 'No', 'Yes' if (x['Enrollment No'],x['code']) in exp_pairs.groups else 'No',
                 i['scheme'],i['type'],i['pub'],'No' if s in hold else 'Yes'])
sheet(wb.create_sheet('Row Check'),['S.No','Enrollment No','Roll No','Student Name','Paper Code','Paper Name','Old Marks','Revised Marks','Student in ERP?','Student+Paper in ERP?','Exam Name(s) in report','Type (ssType)','Result Publish in report','Ready to upload?'],rows,[6,16,13,20,11,30,8,9,9,10,26,8,14,10])
# Mapping
mp=[['sessId','(blank)','Left blank as instructed'],['admno','Enrollment No',''],['rollno','Roll No',''],['studentName','Student Name','S.No 32 placeholder replaced with ERP name'],
 ['subCode','Paper Code','Trimmed + upper-cased'],['subName','Paper Name',''],['ssType','Type from report export (Admno+Code lookup)','All PP'],['examName','Fixed: ETE-1',''],
 ['sequenceNo','Fixed: 1',''],['questionNo','Fixed: 1',''],['marks','Revised Marks','Never edited'],['maxMarks','Max Marks',''],
 ['qType','NOT FILLED','No source column; comes from the exam scheme question setup. Confirm with developer.'],['bloomsLevel','(blank)','As instructed'],['coMapping','(blank)','As instructed'],
 ['coDifficulty','(blank)','As instructed'],['qLabel','(blank)','As instructed'],['acadYear','Fixed: 2025-2026',''],['examSession','Fixed: Revaluation Re Check Form Winter 2025-2026',''],
 ['totalMarks','Revised Marks (assumption)','Single question, so total = question marks. Confirm.'],['totalMaxMarks','Max Marks (assumption)','Confirm.'],
 ['(not used)','S.No, Programme, Semester, Old Marks, Remarks','Used only for validation']]
sheet(wb.create_sheet('Column Mapping'),['Template column','Source','Note'],mp,[18,45,60])
wb.save('out/GU-16432_exceptions.xlsx')
