const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, HeadingLevel,
  AlignmentType, WidthType, ShadingType, BorderStyle, LevelFormat, Footer, PageNumber } = require('docx');

const W = 9026, FONT = 'Arial';
const border = { style: BorderStyle.SINGLE, size: 4, color: 'BFBFBF' };
const borders = { top: border, bottom: border, left: border, right: border };

const runs = (t, o = {}) => {
  // **bold** support
  return t.split(/(\*\*[^*]+\*\*)/).filter(Boolean).map(s =>
    s.startsWith('**') ? new TextRun({ text: s.slice(2, -2), bold: true, ...o }) : new TextRun({ text: s, ...o }));
};
const P = (t, o = {}) => new Paragraph({ children: runs(t, o.run || {}), spacing: { after: 120 }, ...(o.p || {}) });
const H1 = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)] });
const H2 = t => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)] });
const B = (t, lvl = 0) => new Paragraph({ numbering: { reference: 'bul', level: lvl }, children: runs(t), spacing: { after: 60 } });
const N = (t, ref = 'num') => new Paragraph({ numbering: { reference: ref, level: 0 }, children: runs(t), spacing: { after: 60 } });
const Q = t => new Paragraph({ children: runs(t, { italics: true }), indent: { left: 360 }, spacing: { after: 80 },
  border: { left: { style: BorderStyle.SINGLE, size: 12, color: '1F3864', space: 8 } } });

function T(headers, rows, widths) {
  const sum = widths.reduce((a, b) => a + b, 0);
  widths = widths.map(w => Math.round(w * W / sum));
  widths[widths.length - 1] += W - widths.reduce((a, b) => a + b, 0);
  const cell = (t, i, head) => new TableCell({
    borders, width: { size: widths[i], type: WidthType.DXA },
    shading: head ? { fill: '1F3864', type: ShadingType.CLEAR } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: [new Paragraph({ children: runs(String(t), { size: 18, color: head ? 'FFFFFF' : undefined, bold: head || undefined }) })]
  });
  return new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: widths,
    rows: [new TableRow({ tableHeader: true, children: headers.map((h, i) => cell(h, i, true)) }),
      ...rows.map(r => new TableRow({ cantSplit: true, children: r.map((c, i) => cell(c, i, false)) }))]
  });
}
const gap = () => new Paragraph({ spacing: { after: 120 }, children: [] });

const c = [];
// ---------- Title
c.push(new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun('iCloudEMS Support Engineer (AI) Assignment')] }));
c.push(P('**Candidate:** Varun   |   **Tickets:** EX-20481 (Exam-Wise Report) and GU-16432 (Re-evaluation upload)   |   **Tools:** Python (pandas), SQLite 3, Excel, Claude'));
c.push(P('**Files in this zip:** answers.docx (this file), queries.sql, GU-16432_upload_ready.csv, GU-16432_exceptions.xlsx, task2_chart.png, working scripts.'));
c.push(P('**Assumptions made throughout:** (1) "Marks present" means Marks Obtained is not blank. (2) Sr 2767 is a junk/test record; totals are shown with it, and noted where excluding it changes a number. (3) The re-evaluation sheet was received as a CSV, not .xlsx as the brief says; content is the same 41 rows. (4) Re-evaluation is a different session (Winter 2025-26) from the report export (Special Exam Sep 2025-26), so the export is used to confirm students, papers and type, not old marks.'));

// ---------- Task 1
c.push(H1('Task 1: Triage of ticket EX-20481'));
c.push(H2('1.1 What the client is asking for'));
c.push(P('The Deputy COE wants the Exam-Wise Report to show marks again so the exam cell can use it as a worklist to find and finish the results that are still pending for Special Exam Form Sep 2025-2026. The real goal is not "fix the report" but "help us complete pending result processing".'));
c.push(H2('1.2 First guess: bug, data/configuration, or client process?'));
c.push(P('**First guess: a data / configuration problem, not a report bug.** The report reads marks from the live table and nobody reports an error or crash, only "no marks". That usually means the marks are not in the live table (not entered, not transferred from the temp table, or failing with Scheme Not Found because the exam scheme is missing). A client process gap (marks not entered or frozen by faculty) is the second most likely cause. A true report bug is least likely, but will be ruled out by comparing the report with the raw data. (Confirmed in Task 2.)'));
c.push(H2('1.3 Is "High" priority right?'));
c.push(P('**Yes, High is right** (not Critical, because the system is up and no data is lost). The report is the tool the exam cell uses to clear pending results for a special exam session. Every day it is unusable delays results for affected students, which can block their promotion to the next semester, re-exam registration, degree or transcript requests and placements. Results for this session are already being published, so wrong or incomplete publishing is also a risk.'));
c.push(H2('1.4 Questions before starting'));
[ 'Which filters did you select (exam session, programme, semester, course, component) and can you share a screenshot of the empty report?',
  'When did the report last show marks correctly, and what changed since then (marks entry, bulk upload, temp-table transfer, scheme change, result processing)?',
  'Are the marks for these courses entered and frozen by faculty in the marks-entry screen? Do they show there but not in the report?',
  'Internal: was any temp-table transfer run for this session that failed with "Scheme Not Found", and were exam schemes configured for every course in Special Exam Form Sep 2025-2026?',
  'Internal: was any release or change made to the Exam-Wise Report in the last two weeks?'
].forEach(q => c.push(N(q, 'num1')));
c.push(H2('1.5 First response on the ticket (69 words)'));
c.push(Q('Dear Sir/Madam, thank you for raising this. We have picked up ticket EX-20481 and are checking the Exam-Wise Report for Special Exam Form Sep 2025-2026 now. To speed this up, please confirm the filters you selected (session, course, semester), roughly when the report last showed marks, and whether marks were entered or schemes changed since then. We will share our findings within 4 working hours today. Regards, iCloudEMS Support'));

// ---------- Task 2
c.push(new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: true, children: [new TextRun('Task 2: Investigation of the report export')] }));
c.push(H2('2.1 Summary numbers'));
c.push(T(['Measure', 'Answer', 'Note'], [
  ['Total rows', '2,767', '2,766 excluding junk row Sr 2767'],
  ['Unique students (Admno)', '875', '874 excluding junk Admno "1"'],
  ['Unique courses (Code)', '208', '207 excluding junk Code "1"'],
  ['Rows where marks are present', '104', '3.8% of rows; Marks Obtained not blank'],
  ['Rows with Marks Entry Status = Not Done', '1,638', '59.2%'],
  ['Rows with Exam Name = Scheme Not Found', '1,025', '37.0%; 1,024 excluding junk row'],
  ['Rows where Result Publish = Published but marks are not present', '1,849', '703 of them are also Scheme Not Found'],
], [42, 14, 44]));
c.push(gap());
c.push(H2('2.2 Why the report shows no marks'));
c.push(P('**The report is not broken. It is correctly showing data that is missing.** Only 104 of 2,767 rows (3.8%) have a value in Marks Obtained. Every one of those 104 rows has Marks Entry Status = Done, and no "Not Done" row has marks, so the report is consistent with the marks status. The other 2,663 rows are empty for two reasons: 1,638 rows are Marks Entry Status = Not Done (marks never entered; 1,619 of them also have no Alloted EmpId, so no faculty member was assigned to enter them), and 1,025 rows have Exam Name = Scheme Not Found with blank status, freeze and max marks, meaning no exam scheme exists so marks cannot be stored at all. Max Marks is blank on exactly the same 2,663 rows. Meanwhile Result Process / Result Publish show 1,849 of these empty rows as Published, which is why the client believes marks "used to be there".'));
c.push(H2('2.3 Data problems found (15 kinds)'));
c.push(T(['#', 'Anomaly', 'Column(s)', 'Rows', 'Example Sr.', 'Why it matters for result processing'], [
  ['1', 'Marks not entered', 'Marks Entry Status, Marks Obtained', '1,638', '5', 'Result cannot be calculated; main cause of empty report'],
  ['2', 'Missing exam scheme (missing master data)', 'Exam Name = Scheme Not Found', '1,025', '7', 'Marks cannot be stored or transferred until scheme is configured'],
  ['3', 'Result published with no marks', 'Result Publish, Marks Obtained', '1,849', '5', 'Students may have wrong/blank published results'],
  ['4', 'Result published with no scheme', 'Result Publish, Exam Name', '703', '7', 'Published on a course that has no evaluation scheme'],
  ['5', 'Processed / published while marks Not Done and Unfreeze', 'Result Process, Result Publish, Marks Entry Status, Freeze', '1,173 processed / 1,146 published', '5', 'Processing should only run on frozen marks; results must be re-processed'],
  ['6', 'Published while Not Registered', 'Register Status, Result Publish', '1,878', '5', 'Result published for students not registered for the exam'],
  ['7', 'Negative marks (-100)', 'Marks Obtained', '10', '222', 'Impossible value; looks like an "absent" code stored as marks'],
  ['8', 'Scaled marks do not match marks', 'Scaled Marks vs Marks Obtained', '9', '222', '-100 scaled to 0: result would use 0 silently'],
  ['9', 'Exact duplicate rows', 'All columns except Sr.', '2 pairs (4 rows)', '1974 = 2092', 'Double counting; one copy must be removed'],
  ['10', 'Same student + course + component under two Class records', 'Admno, Code, Exam Name, Class, Semester', '313 pairs (non-SNF) + 87 SNF rows', '214 / 219', 'Student appears in two class lists; risk of two different results'],
  ['11', 'Same student + course has both an ETE-1 row and a Scheme Not Found row', 'Exam Name', '956 student-courses', '5 / 7', 'Scheme exists for one class mapping but not the other'],
  ['12', 'Conflicting status for same student + course', 'Marks Entry Status, Freeze', '1 pair', '1293 / 1312', 'One row Done+Freezed (80), other Not Done; which is final?'],
  ['13', 'Junk / test record', 'Admno "1", Student "1 1 1", Type "1", Code "1", blank Exam Session', '1', '2767', 'Architecture 2016-17 record in a SCSE 2025-26 export; must be removed'],
  ['14', 'Inconsistent semester spellings', 'Semester (17 variants: SEm V, SEM III, Sem 9...)', '140', '1', 'Breaks grouping, filters and semester-wise result runs'],
  ['15', 'Other master-data gaps / inconsistencies', 'Alloted EmpId blank; Department spelling; Max Marks blank; names with double spaces', '2,748 / 10 / 2,663 / 2,766', '1 / 941 vs 1696', 'No faculty allotted = nobody can enter marks; near-duplicate department names split reports'],
], [6, 21, 20, 14, 11, 28]));
c.push(gap());
c.push(H2('2.4 Where to start'));
c.push(P('**Top 5 courses with most "Not Done" rows** (client to get marks entered):'));
c.push(T(['Rank', 'Code', 'Course', 'Not Done rows'], [
  ['1', 'E1UA202T', 'Probability And Statistics', '258'], ['2', 'R1UC601B', 'Advanced Algorithmic Problem Solving', '164'],
  ['3', 'C1UC323T', 'Linear Algebra', '138'], ['4', 'C1UC121B', 'Multi Variable Calculus', '75'], ['5', 'C1UC322T', 'Probability And Statistics', '70'],
], [10, 18, 52, 20]));
c.push(gap());
c.push(P('**Department + Semester with most "Scheme Not Found" rows** (semester spellings standardised first; developers to configure schemes):'));
c.push(T(['Rank', 'Department', 'Semester', 'SNF rows'], [
  ['1', 'Bachelor of Computer Applications', 'Sem II', '101'], ['2', 'B.Tech Computer Science and Engineering', 'Sem VI', '92'],
  ['3', 'Bachelor of Computer Applications', 'Sem IV', '85'], ['4', 'B.Tech Computer Science and Engineering', 'Sem III', '79'],
  ['5', 'B.Tech Computer Science and Engineering', 'Sem II', '72'],
], [10, 52, 18, 20]));
c.push(gap());
c.push(H2('2.5 Chart'));
c.push(new Paragraph({ alignment: AlignmentType.CENTER, children: [new ImageRun({ type: 'png', data: fs.readFileSync('out/task2_chart.png'), transformation: { width: 600, height: 240 } })] }));
c.push(P('**Caption:** 96% of report rows have no marks to show: 59% were never entered and 37% have no exam scheme. The report itself is working.', { run: { italics: true } }));

// ---------- Task 3 pointer
c.push(H1('Task 3: SQL'));
c.push(P('Submitted as **queries.sql** (SQLite 3). It loads the CSV into a raw text table, then into typed table exam_wise_report with snake_case columns, converting blank cells to NULL and marks to numbers (otherwise "IS NULL" finds nothing and "-100" > "100" compares as text). Every query was run and its row count is written as a comment.'));
c.push(T(['Query', 'Rows returned', 'Key result'], [
  ['Q1 exam_name x marks_entry_status', '5', 'ETE-1/Not Done 1,607; SNF/blank 1,025; Practical/Done 100; Practical/Not Done 31; ETE-1/Done 4'],
  ['Q2 Published but marks Not Done / missing', '1,849', 'Matches Task 2'],
  ['Q3 Duplicate admno+code+exam_name', '356 keys', '352 appear twice, 4 appear three times; Q3b shows only 2 are exact copies'],
  ['Q4 Impossible marks', '10', 'All -100; 9 of them scaled to 0'],
  ['Q5 Semester clean-up', '17 values -> 9', 'Backup table + transaction + WHERE; 140 rows updated'],
  ['Q6 Missing schemes for developers', '272', 'Top: BCA Sem II C1UC323T Linear Algebra, 74 students'],
  ['Bonus morning health check', '1 row per session', 'Flags ALERT when any published-without-marks / SNF / impossible marks exist'],
], [34, 16, 50]));

// ---------- Task 4
c.push(H1('Task 4: Re-evaluation upload (GU-16432)'));
c.push(H2('4.1 / 4.2 Result of validation and conversion'));
c.push(P('41 rows received. **33 rows are in GU-16432_upload_ready.csv; 8 rows are held or sent back** (S.No 4, 12, 16, 20, 23, 28, 36, 41). No mark was changed by support. Two format-only fixes were made and logged: S.No 8 paper code "k1uc428t " to K1UC428T, and S.No 32 placeholder name "Wrong Name Typed" replaced with the ERP name Kavya Singh (Enrollment No, Roll No and programme all match). Full detail, row-by-row checks and the column mapping are in GU-16432_exceptions.xlsx.'));
c.push(T(['S.No', 'Problem', 'Action'], [
  ['4', 'Revised 112 out of 100', 'Send back; never cap or guess'],
  ['12', 'Enrollment No has 14 characters, not in ERP', 'Send back for correct ID'],
  ['16', 'Revised = AB with "?" remark', 'Hold; COE decides (see 4.4)'],
  ['20', 'Revised marks blank', 'Send back'],
  ['23', 'Revised 41 lower than old 47', 'Hold for written COE approval (see 4.4)'],
  ['28 / 41', 'Same student + paper twice, revised 28 vs 31', 'Send back; upload neither'],
  ['36', 'Revised 30.5 (half mark)', 'Hold; confirm half marks are allowed, do not round'],
], [12, 50, 38]));
c.push(gap());
c.push(P('**Columns not filled:** qType (no source column; it comes from the exam scheme question set-up, to confirm with developer). totalMarks and totalMaxMarks were filled as marks and maxMarks on the assumption that a single-question (questionNo 1) entry has total = question marks; flagged for confirmation. sessId, bloomsLevel, coMapping, coDifficulty and qLabel left blank as instructed. ssType taken from the report export Type (all PP).'));
c.push(P('**Important risk found:** 31 of the 41 student-papers appear in the report export with both an ETE-1 row and a "Scheme Not Found" row, and none of them have old marks in the export. So the Old Marks column cannot be verified in the ERP, and the scheme for these papers must be confirmed for the Winter 2025-26 revaluation session before the transfer.'));
c.push(H2('4.3 Checklist before pressing Submit on "Update Student Marks Data from Temp Table"'));
[ 'Get written client approval of the exception list; only the 33 clean rows go in. Held rows are uploaded later as a separate batch once the COE replies.',
  'Confirm the exam scheme (ETE-1, max 100) exists for every subCode in the session "Revaluation Re Check Form Winter 2025-2026", especially the 31 papers that show Scheme Not Found in the report.',
  'Take a backup / export of the current live marks for these 33 students and papers (old values), so the change can be reversed.',
  'Check marks are not frozen / results not locked in a way that blocks the update; get approval to unfreeze if required.',
  'Load into the temp table and re-count: 33 rows, 33 distinct admno+subCode, no blanks in admno, subCode, marks; all marks between 0 and 100.',
  'Spot-check 3 rows in the temp table against the client sheet (e.g. S.No 1, 8, 32).',
  'Run the transfer on a test copy / staging first if available; otherwise run during low usage and inform the client.',
] .forEach(q => c.push(N(q, 'num2')));
c.push(P('**After Submit:** compare success count with 33. Any row that fails with "Scheme Not Found" again is not forced in: export the failed rows, raise them to the developer with the session, subCode and department to configure the scheme, then re-run only those rows. Then open the Exam-Wise Report / student marks for the spot-check students to confirm revised marks show, confirm with the COE office before result re-processing, and record batch counts on the ticket.'));
c.push(H2('4.4 Lower revised marks (S.No 23) and AB (S.No 16)'));
c.push(P('**S.No 23, Myra Nair, C1UC125T: 47 to 41.** Support does not decide this. Many universities protect students from a decrease on re-check, others apply the new mark. We hold the row and ask the COE / Controller of Examination to confirm in writing that the decrease is correct and allowed by the university\'s revaluation rules. Only then is it uploaded, in a separate batch, with the approval attached to the ticket.'));
c.push(P('**S.No 16, Ayush Saxena, E2UC502T: old 57, revised "AB".** A re-check re-evaluates an answer script the student already wrote (they scored 57), so "Absent" is not a valid re-check outcome and the client\'s own remark has a question mark. Uploading AB could wipe a real mark and fail the student. We hold the row and ask the COE office to confirm the correct outcome (most likely "no change, keep 57" or a corrected number). The COE / Controller of Examination decides; support only uploads what they confirm in writing.'));

// ---------- Task 5
c.push(H1('Task 5: Client reply and developer escalation'));
c.push(H2('5.1 Reply to the Deputy Controller of Examination (167 words)'));
const reply = [
  'Dear Sir/Madam,',
  'We have checked the Exam-Wise Report for Special Exam Form Sep 2025-2026. The report is working correctly: it shows exactly the marks stored in the system. The problem is that most marks have not reached the system yet.',
  'Out of 2,767 student-course records, only 104 (4%) have marks. 1,638 records have marks not entered, mostly because no faculty member is allotted to enter them, and 1,024 records cannot hold marks because the exam scheme for that course is not set up.',
  'What we need from your office: please allot faculty and get marks entered and frozen, starting with Probability and Statistics (E1UA202T), Advanced Algorithmic Problem Solving (R1UC601B) and Linear Algebra (C1UC323T). The full course-wise list is attached.',
  'What we will do: set up the missing exam schemes by Tuesday, 24 November 2026, and remove one test record and two duplicate entries once you confirm.',
  'Note: 1,849 records show results as published without marks. We suggest holding further publishing until marks are complete.',
  'Regards,', 'iCloudEMS Support'];
reply.forEach(t => c.push(Q(t)));
c.push(H2('5.2 Internal escalation to developer'));
[ '**Ticket:** EX-20481, Exam-Wise Report shows no marks, Special Exam Form Sep 2025-2026 SCSE, raised by Deputy COE, priority High.',
  '**What I checked:** full report export (2,767 rows x 26 columns) in Python and SQLite; status columns cross-checked against marks.',
  '**Conclusion:** report logic is fine. All 104 rows with marks show Done; no Not Done row has marks. Missing data, not a display bug.',
  '**Evidence:** 1,638 rows Not Done (1,619 with no Alloted EmpId); 1,025 rows Exam Name = "Scheme Not Found"; 1,849 rows Result Publish = Published with no marks, 703 of them with no scheme; 1,173 rows Processed while marks Not Done.',
  '**Example records:** Sr 5 and Sr 7, Admno 20SCSE4659729, BTCS3602: one row ETE-1 Not Done, one row Scheme Not Found, both Processed + Published. Sr 222, Admno 20SCSE5643052, BTCS3551: marks -100, scaled 0.',
  '**Suspected root cause:** (1) exam schemes not configured for 272 department/semester/course combinations of this session (956 student-courses have the scheme under one Class record but not another, so likely class/batch mapping when students were carried over); (2) result processing/publishing ran without checking marks are entered and frozen.',
  '**What I need from you:** (a) configure schemes from the attached Q6 list (sorted by students affected, top: BCA Sem II C1UC323T, 74 students) and re-run the temp-table transfer; (b) check why Result Process allowed Processed/Published with Not Done / Unfreeze marks and whether those 1,849 results must be rolled back; (c) remove junk row Sr 2767 (Admno "1") and exact duplicates Sr 2092, 2093 after client OK; (d) check the -100 values (10 rows, Q4) and the 313 student-courses listed under two Class records.',
  '**Attached:** queries.sql (Q2, Q3, Q4, Q6 outputs), exam_wise_report_export.csv, task2_chart.png. Client has been told schemes will be set up by Tue 24 Nov 2026; please confirm ETA today.',
].forEach(t => c.push(B(t)));

// ---------- Task 6
c.push(H1('Task 6: How I used AI'));
c.push(H2('6.1 Three most useful prompts'));
c.push(T(['Prompt', 'What it helped with'], [
  ['"Give me the summary of each task. In simple, short and direct, easy-to-understand language."', 'Turned the 7-page brief into a one-screen checklist of deliverables, so nothing was missed (e.g. the 80/120-180 word limits, the .sql row-count comments).'],
  ['"Work on these tasks priority-wise and try to break each task. If it breaks, tell me why, what needs to be done and how we can improve it, before proceeding."', 'Made the AI profile the data and stress-test each task first. It found the traps up front: blank Max Marks hiding the "> max" check, text-vs-number comparison in SQL, CSV blanks not being NULL, the revaluation sheet\'s conflicts with the report.'],
  ['"Profile exam_wise_report_export.csv: value counts for every status column, then cross-tab status combinations that should not exist, duplicates on Admno+Code+Exam Name, and impossible marks. Give one example Sr. for each."', 'Produced the anomaly list for Task 2.3 and the example records used in the developer escalation.'],
], [50, 50]));
c.push(gap());
c.push(H2('6.2 Where the AI was wrong and how I caught it'));
c.push(B('**Duplicates over-counted:** the first check on Admno + Code + Exam Name flagged 360 extra rows as "duplicates". I asked what actually differs between the pairs: almost all differ in Class / Semester (the same student under two class records). Only 2 pairs are exact copies. Reported both numbers separately.'));
c.push(B('**Wrong count in a comment:** the AI wrote "3 keys appear 3 times, 353 twice" in queries.sql. Re-counting in pandas gave 4 and 352 (total 356 still right). Fixed before submission; every number in this document was re-run, not typed from memory.'));
c.push(B('**A check that silently returned 0:** "marks greater than Max Marks" returned 0 rows. Rather than accept "no problem", I checked why: Max Marks is blank on all 2,663 rows without marks, so the check only tests 104 rows. Negative marks (-100) were the real impossible values.'));
c.push(H2('6.3 How an AI agent could handle these tickets (5 lines)'));
[ 'On every upload file: an agent checks IDs exist in the ERP, admno+subCode match the student\'s registered courses, marks are numeric and within 0-max, no duplicates, no AB/blank, decreases vs old marks, and that the exam scheme exists for that session.',
  'It auto-fixes only format issues (case, spaces, semester spelling), writes the exception list and a draft client reply, and builds the temp-table file.',
  'For report tickets it runs the morning health-check query and attaches counts, examples and a draft developer escalation.',
  'A human must approve: any change to marks, AB/decrease decisions (COE), the temp-table transfer, result processing/publishing, and deleting any record.',
  'Every agent action is logged on the ticket so support can audit what was checked and changed.',
].forEach(t => c.push(N(t, 'num3')));

const doc = new Document({
  creator: 'Varun', title: 'iCloudEMS Support Engineer (AI) Assignment - Answers',
  styles: {
    default: { document: { run: { font: FONT, size: 20 } } },
    paragraphStyles: [
      { id: 'Title', name: 'Title', basedOn: 'Normal', run: { font: FONT, size: 36, bold: true, color: '1F3864' }, paragraph: { spacing: { before: 0, after: 200 }, keepNext: true } },
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 28, bold: true, color: '1F3864' }, paragraph: { spacing: { before: 320, after: 120 }, keepNext: true, outlineLevel: 0 } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 22, bold: true, color: '2E5597' }, paragraph: { spacing: { before: 200, after: 80 }, keepNext: true, outlineLevel: 1 } },
    ]
  },
  numbering: { config: [
    { reference: 'bul', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] },
    ...['num', 'num1', 'num2', 'num3'].map(r => ({ reference: r, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] }))
  ] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: 'Varun - iCloudEMS Support Engineer (AI) - Page ', size: 16, color: '808080' }), new TextRun({ children: [PageNumber.CURRENT], size: 16, color: '808080' })] })] }) },
    children: c
  }]
});
Packer.toBuffer(doc).then(b => fs.writeFileSync('out/answers.docx', b));
