import sqlite3, csv, sys, re
src, csvp, out = sys.argv[1:4]
con=sqlite3.connect(':memory:', isolation_level=None)
lines=open(src).read().split('\n'); res=[]; buf=''; last=None; results={}
for ln in lines:
    s=ln.strip()
    if s.startswith('.import'):
        rows=list(csv.reader(open(csvp,newline='',encoding='utf-8')))[1:]
        con.executemany('INSERT INTO exam_wise_report_raw VALUES (%s)'%','.join('?'*26),rows)
        res.append(ln); continue
    m=re.match(r'--@(\w+)',s)
    if m:
        res.append(f'-- rows returned: {last}' if not m.group(1).startswith('Q5c') else f'-- rows updated: {last}')
        results[m.group(1)]=lastrows; continue
    res.append(ln)
    if s.startswith('--') and not buf: continue
    buf+=ln+'\n'
    if sqlite3.complete_statement(buf):
        cur=con.execute(buf); 
        try: lastrows=cur.fetchall()
        except Exception: lastrows=[]
        last = len(lastrows) if cur.description else cur.rowcount
        buf=''
open(out,'w').write('\n'.join(res))
for k,v in results.items(): print(k,len(v),v[:6])
