-- =====================================================================
-- iCloudEMS Support Engineer (AI) Assignment - Task 3
-- Ticket EX-20481 - Exam-Wise Report (Special Exam Form Sep 2025-2026)
-- Run:    sqlite3 ewr.db < queries.sql   (from the folder holding the CSV)
-- Engine: SQLite 3 (allowed by the brief). Tested on SQLite 3.53.
-- Row counts written as "-- rows returned: N" were produced by actually
-- running this file against exam_wise_report_export.csv (2,767 rows).
-- =====================================================================

-- ---------------------------------------------------------------------
-- 0. LOAD
-- Step A: raw table, every column TEXT, snake_case names.
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS exam_wise_report_raw;
CREATE TABLE exam_wise_report_raw (
  sr_no TEXT, exam_session TEXT, academic_year TEXT, branch TEXT, department TEXT,
  class TEXT, semester TEXT, batch TEXT, admno TEXT, rollno TEXT, student TEXT,
  division TEXT, course TEXT, code TEXT, type TEXT, alloted_empid TEXT,
  exam_name TEXT, marks_entry_status TEXT, marks_obtained TEXT, max_marks TEXT,
  freeze_unfreeze_status TEXT, scaled_marks TEXT, scaled_max_marks TEXT,
  register_status TEXT, result_process TEXT, result_publish TEXT
);
-- In the sqlite3 CLI:
.import --csv --skip 1 exam_wise_report_export.csv exam_wise_report_raw

-- Step B: typed table. Two traps fixed here:
--   (1) CSV blanks load as '' not NULL, so "IS NULL" would return 0 rows -> NULLIF.
--   (2) Marks load as TEXT, so '-100' > '100' compares as text -> CAST to REAL.
DROP TABLE IF EXISTS exam_wise_report;
CREATE TABLE exam_wise_report (
  sr_no                  INTEGER PRIMARY KEY,
  exam_session           TEXT,
  academic_year          TEXT,
  branch                 TEXT,
  department             TEXT,
  class                  TEXT,
  semester               TEXT,
  batch                  TEXT,
  admno                  TEXT,
  rollno                 TEXT,
  student                TEXT,
  division               TEXT,
  course                 TEXT,
  code                   TEXT,
  type                   TEXT,     -- PP = theory, PR = practical
  alloted_empid          TEXT,
  exam_name              TEXT,     -- component: ETE-1 / Practical ETE-1 / Scheme Not Found
  marks_entry_status     TEXT,
  marks_obtained         REAL,
  max_marks              REAL,
  freeze_unfreeze_status TEXT,
  scaled_marks           REAL,
  scaled_max_marks       REAL,
  register_status        TEXT,
  result_process         TEXT,
  result_publish         TEXT
);

INSERT INTO exam_wise_report
SELECT CAST(sr_no AS INTEGER),
       NULLIF(TRIM(exam_session),''), NULLIF(TRIM(academic_year),''), NULLIF(TRIM(branch),''),
       NULLIF(TRIM(department),''), NULLIF(TRIM(class),''), NULLIF(TRIM(semester),''),
       NULLIF(TRIM(batch),''), NULLIF(TRIM(admno),''), NULLIF(TRIM(rollno),''),
       NULLIF(TRIM(student),''), NULLIF(TRIM(division),''), NULLIF(TRIM(course),''),
       NULLIF(TRIM(code),''), NULLIF(TRIM(type),''), NULLIF(TRIM(alloted_empid),''),
       NULLIF(TRIM(exam_name),''), NULLIF(TRIM(marks_entry_status),''),
       CAST(NULLIF(TRIM(marks_obtained),'') AS REAL), CAST(NULLIF(TRIM(max_marks),'') AS REAL),
       NULLIF(TRIM(freeze_unfreeze_status),''),
       CAST(NULLIF(TRIM(scaled_marks),'') AS REAL), CAST(NULLIF(TRIM(scaled_max_marks),'') AS REAL),
       NULLIF(TRIM(register_status),''), NULLIF(TRIM(result_process),''), NULLIF(TRIM(result_publish),'')
FROM exam_wise_report_raw;

-- Load check
SELECT COUNT(*) AS total_rows,
       COUNT(DISTINCT admno) AS unique_students,
       COUNT(DISTINCT code)  AS unique_courses,
       COUNT(marks_obtained) AS rows_with_marks
FROM exam_wise_report;
-- rows returned: 1  -> total 2767 | unique admno 875 | unique code 208 | rows with marks 104

-- ---------------------------------------------------------------------
-- Q1. Rows per exam_name x marks_entry_status
-- ---------------------------------------------------------------------
SELECT exam_name,
       COALESCE(marks_entry_status, '(blank)') AS marks_entry_status,
       COUNT(*) AS row_count
FROM exam_wise_report
GROUP BY exam_name, marks_entry_status
ORDER BY row_count DESC;
-- rows returned: 5
--   ETE-1            | Not Done | 1607
--   Scheme Not Found | (blank)  | 1025
--   Practical ETE-1  | Done     |  100
--   Practical ETE-1  | Not Done |   31
--   ETE-1            | Done     |    4

-- ---------------------------------------------------------------------
-- Q2. Result Published, but marks for that course are Not Done or missing
-- ---------------------------------------------------------------------
SELECT admno, student, code, course, exam_name
FROM exam_wise_report
WHERE result_publish = 'Published'
  AND (marks_entry_status = 'Not Done' OR marks_obtained IS NULL)
ORDER BY code, admno;
-- rows returned: 1849

-- ---------------------------------------------------------------------
-- Q3. Duplicate records: same admno + code + exam_name more than once
-- ---------------------------------------------------------------------
SELECT admno, code, exam_name, COUNT(*) AS times_seen,
       GROUP_CONCAT(sr_no) AS sr_numbers
FROM exam_wise_report
GROUP BY admno, code, exam_name
HAVING COUNT(*) > 1
ORDER BY times_seen DESC, admno, code;
-- rows returned: 356  (key groups; 4 keys appear 3 times, 352 appear twice)

-- Q3b. Refinement: of those, the ones that are exact copies (every column
-- except sr_no identical). These are the only true "delete one" duplicates;
-- the rest are the same student+course under two Class / semester records.
SELECT admno, code, exam_name, semester, class, COUNT(*) AS times_seen,
       GROUP_CONCAT(sr_no) AS sr_numbers
FROM exam_wise_report
GROUP BY exam_session, academic_year, branch, department, class, semester, batch,
         admno, rollno, student, division, course, code, type, alloted_empid,
         exam_name, marks_entry_status, marks_obtained, max_marks,
         freeze_unfreeze_status, scaled_marks, scaled_max_marks,
         register_status, result_process, result_publish
HAVING COUNT(*) > 1;
-- rows returned: 2  -> Sr 1974 = 2092 and Sr 1975 = 2093 are exact copies

-- ---------------------------------------------------------------------
-- Q4. Impossible marks
-- ---------------------------------------------------------------------
SELECT sr_no, admno, student, code, exam_name,
       marks_obtained, max_marks, scaled_marks, scaled_max_marks,
       CASE WHEN marks_obtained < 0 THEN 'negative marks'
            WHEN marks_obtained > max_marks THEN 'marks above max'
            ELSE 'scaled marks do not match marks' END AS problem
FROM exam_wise_report
WHERE marks_obtained < 0
   OR marks_obtained > max_marks
   OR (max_marks = scaled_max_marks AND scaled_marks <> marks_obtained)
ORDER BY sr_no;
-- rows returned: 10
-- Note: marks > max_marks finds 0 rows. That is real, not a blind spot:
-- max_marks is NULL on all 2,663 rows that have no marks, but present on all
-- 104 rows that do. Sr 426 is negative (-100) and its scaled mark is also -100,
-- so it shows only as 'negative'; the other 9 negatives have scaled_marks = 0.

-- ---------------------------------------------------------------------
-- Q5. Semester spellings: preview -> backup -> guarded UPDATE -> verify
-- ---------------------------------------------------------------------
-- 5a. Preview original vs cleaned value (nothing changes yet)
SELECT semester AS original_value,
       CASE UPPER(TRIM(SUBSTR(TRIM(semester), INSTR(TRIM(semester), ' ') + 1)))
            WHEN '9' THEN 'Sem IX'
            ELSE 'Sem ' || UPPER(TRIM(SUBSTR(TRIM(semester), INSTR(TRIM(semester), ' ') + 1)))
       END AS cleaned_value,
       COUNT(*) AS row_count
FROM exam_wise_report
GROUP BY semester
ORDER BY cleaned_value, original_value;
-- rows returned: 17

-- 5b. Protect the data first: full backup copy of the table
DROP TABLE IF EXISTS exam_wise_report_bak_20261120;
CREATE TABLE exam_wise_report_bak_20261120 AS SELECT * FROM exam_wise_report;
SELECT (SELECT COUNT(*) FROM exam_wise_report) AS live_rows,
       (SELECT COUNT(*) FROM exam_wise_report_bak_20261120) AS backup_rows;
-- rows returned: 1

-- 5c. Guarded UPDATE inside a transaction. The WHERE clause touches only
-- rows whose value is actually non-standard and that start with 'sem'.
BEGIN TRANSACTION;
UPDATE exam_wise_report
SET semester = CASE UPPER(TRIM(SUBSTR(TRIM(semester), INSTR(TRIM(semester), ' ') + 1)))
                    WHEN '9' THEN 'Sem IX'
                    ELSE 'Sem ' || UPPER(TRIM(SUBSTR(TRIM(semester), INSTR(TRIM(semester), ' ') + 1)))
               END
WHERE UPPER(semester) LIKE 'SEM %'
  AND semester <> CASE UPPER(TRIM(SUBSTR(TRIM(semester), INSTR(TRIM(semester), ' ') + 1)))
                       WHEN '9' THEN 'Sem IX'
                       ELSE 'Sem ' || UPPER(TRIM(SUBSTR(TRIM(semester), INSTR(TRIM(semester), ' ') + 1)))
                  END;
-- rows updated: 140
-- 5d. Verify before COMMIT: only the 8 standard spellings should remain.
-- If anything looks wrong: ROLLBACK;  (or restore from exam_wise_report_bak_20261120)
SELECT semester, COUNT(*) AS row_count FROM exam_wise_report GROUP BY semester ORDER BY semester;
-- rows returned: 9
COMMIT;

-- ---------------------------------------------------------------------
-- Q6. Missing exam schemes for developers to configure
-- (semester already standardised by Q5; junk record Sr 2767 excluded
--  because its admno '1' is not a valid 13-character enrollment number)
-- ---------------------------------------------------------------------
SELECT department, semester, code, course,
       COUNT(DISTINCT admno) AS students_affected,
       COUNT(*) AS rows_affected
FROM exam_wise_report
WHERE exam_name = 'Scheme Not Found'
  AND LENGTH(admno) = 13
GROUP BY department, semester, code, course
ORDER BY students_affected DESC, department, semester, code;
-- rows returned: 272

-- ---------------------------------------------------------------------
-- BONUS. Morning health check for exam season.
-- One query, one row per exam session; any non-zero column means act today.
-- ---------------------------------------------------------------------
SELECT exam_session,
       COUNT(*)                                                         AS total_rows,
       SUM(exam_name = 'Scheme Not Found')                              AS scheme_not_found,
       SUM(marks_entry_status = 'Not Done')                             AS marks_not_done,
       SUM(result_publish = 'Published' AND marks_obtained IS NULL)     AS published_without_marks,
       SUM(result_publish = 'Published' AND exam_name = 'Scheme Not Found') AS published_without_scheme,
       SUM(marks_obtained < 0 OR marks_obtained > max_marks)            AS impossible_marks,
       SUM(LENGTH(admno) <> 13 OR exam_session IS NULL)                 AS junk_rows,
       ROUND(100.0 * COUNT(marks_obtained) / COUNT(*), 1)               AS pct_rows_with_marks,
       CASE WHEN SUM(result_publish = 'Published' AND marks_obtained IS NULL) > 0
              OR SUM(exam_name = 'Scheme Not Found') > 0
              OR SUM(marks_obtained < 0 OR marks_obtained > max_marks) > 0
            THEN 'ALERT' ELSE 'OK' END                                  AS status
FROM exam_wise_report
GROUP BY exam_session
ORDER BY status, published_without_marks DESC;
-- rows returned: 2  -> SCSE session: ALERT (1849 published without marks, 1024 scheme not found,
--                      10 impossible marks); NULL session: the junk row Sr 2767
